package com.sortnumbers.model;

public class UserInput {

	private String unSortedNumbers;

	public UserInput() {
	}

	/**
	 * @param unSortedNumbers
	 */
	public UserInput(String unSortedNumbers) {
		this.unSortedNumbers = unSortedNumbers;
	}

	/**
	 * @return the unSortedNumbers
	 */
	public String getUnSortedNumbers() {
		return unSortedNumbers;
	}

	/**
	 * @param unsortednumbers
	 *            the unSortedNumbers to set
	 */
	public void setUnsortednumbers(String unSortedNumbers) {
		this.unSortedNumbers = unSortedNumbers;
	}

}
