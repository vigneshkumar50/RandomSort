package com.sortnumbers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SortApplication {

	public static void main(String[] args) {
		SpringApplication.run(SortApplication.class, args);
	}
}
